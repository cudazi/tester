<?php
  echo 'Hello';
  echo '<br />Hello again.';
  echo '<br />Hello again and again.';